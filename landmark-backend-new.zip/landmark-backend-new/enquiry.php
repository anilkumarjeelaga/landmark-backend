<?php
// this is for home page enquiry page
$host='localhost';
$user='hellochat1';
$pw='hellochat';
$conn=mysql_connect($host,$user,$pw);
if(!$conn){
    die().mysql_error();
}
$db=mysql_select_db("avrslandmark",$conn);
if(!$db){
    echo "database not connected";
}

 header("location:index.php");
$name_error = $email_error = $mobile_error = "";

$name  = $email =$mobile = $message = $success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (empty($_POST["name"])) {

        $name_error = "Name is required";

    } else {

        $name = test_input($_POST["name"]);

    // check if name only contains letters and whitespace

        if (!preg_match("/^[a-zA-Z ]*$/",$name)) {

            $name_error = "Only letters and white space allowed"; 

        }

    }



  if (empty($_POST["email"])) {

    $email_error = "Email ID is required";

  } else {

    $email = test_input($_POST["email"]);

    // check if e-mail address is well-formed

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

      $email_error = "Invalid email format"; 

    }

  }

  if (empty($_POST["mobile"])) {

    $mobile_error = "Mobile is required";

  } else {

    $mobile = test_input($_POST["mobile"]);

    // check if e-mail address is well-formed

    if (!preg_match("/^(\d[\s-]?)?[\(\[\s-]{0,2}?\d{3}[\)\]\s-]{0,2}?\d{3}[\s-]?\d{4}$/i",$mobile)) {

      $mobile_error = "Invalid mobile number"; 

    }

  } 

  if (empty($_POST["message"])) {

    $message = "";

  } else {

    $message = test_input($_POST["message"]);

  }  

  if ($name_error == '' and $email_error == ''){

      $message_body = '';

      unset($_POST['submit']);

      foreach ($_POST as $key => $value){

          $message_body .=  "$key: $value\n";

      }

      $que="insert into enquiry(name,email,mobile,message)values('$name','$email','$mobile','$message')";
 $to = "landmarktownships@gmail.com";

  $email_from = '$email';

    $email_subject = "Enquiry";

    $email_body = "You have received a new message from the user $name.\n"."Here is the message:\n $message \n Mobile Number: $mobile";
      $headers = "From: $email_from \r\n";


            mail("landmarktownships@gmail.com","enquiry",$email_body);

      if(mysql_query($que)){      

          $success = "Enquiry form submits";

          $name = $email = $mobile = $message = '';

          

            mail("landmarktownships@gmail.com","enquiry",$email_body);
             if(mail){header("location: index.php");

      }

  }  }

}

function test_input($data) {

  $data = trim($data);

  $data = stripslashes($data);

  $data = htmlspecialchars($data);

  return $data;

}

?>

