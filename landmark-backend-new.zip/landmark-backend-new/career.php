<!doctype html>
<!--[if IE 7 ]>    <html lang="en-gb" class="isie ie7 oldie no-js"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en-gb" class="isie ie8 oldie no-js"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en-gb" class="isie ie9 no-js"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<!--<![endif]-->
<!--<![endif]-->
<html lang="en">


    
<head>
<title>Welcome to Landmark Townships</title>
<meta charset="utf-8">
<!-- Meta -->
<meta name="keywords" content="" />
<meta name="author" content="">
<meta name="robots" content="" />
<meta name="description" content="" />

<!-- this styles only adds some repairs on idevices  -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- Favicon -->
<link rel="shortcut icon" href="images/favicon.html">
<!-- Google fonts - witch you want to use - (rest you can just remove) -->

<!-- Google fonts - witch you want to use - (rest you can just remove) -->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Roboto:100,200,300,400,500,600,700,800,900' rel='stylesheet' type='text/css'>

<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

<!-- stylesheets -->

<link rel="stylesheet" media="screen" href="js/bootstrap/bootstrap.min.css" type="text/css" />
<link rel="stylesheet" href="js/mainmenu/menu.css" type="text/css" />
<link rel="stylesheet" href="css/default.css" type="text/css" />
<link rel="stylesheet" href="css/layouts.css" type="text/css" />
<link rel="stylesheet" href="css/shortcodes.css" type="text/css" />
<link rel="stylesheet" href="css/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" media="screen" href="css/responsive-leyouts.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/Simple-Line-Icons-Webfont/simple-line-icons.css" media="screen" />
<link rel="stylesheet" href="css/et-line-font/et-line-font.css">
<link rel="stylesheet" href="js/style-swicher/style-swicher.css" type="text/css" />
<link rel="stylesheet" href="js/custom-scrollbar/jquery.mCustomScrollbar.css">
<link rel="stylesheet" type="text/css" href="js/smart-forms/smart-forms.css">
<link rel="stylesheet" type="text/css" href="css/Simple-Line-Icons-Webfont/simple-line-icons.css" media="screen" />
<link rel="stylesheet" href="css/et-line-font/et-line-font.css">
<link rel="stylesheet" href="js/style-swicher/style-swicher.css" type="text/css" />
<link href="js/owl-carousel/owl.carousel.css" rel="stylesheet">
<link rel="stylesheet" href="js/tabs/assets/css/responsive-tabs.css" />

<!-- Remove the below comments to use your color option -->
<!--<link rel="stylesheet" href="css/colors/lightblue.css" />-->
<!--<link rel="stylesheet" href="css/colors/orange.css" />-->
<!--<link rel="stylesheet" href="css/colors/green.css" />-->
<!--<link rel="stylesheet" href="css/colors/pink.css" />-->
<!--<link rel="stylesheet" href="css/colors/red.css" />-->
<!--<link rel="stylesheet" href="css/colors/purple.css" />-->
<!--<link rel="stylesheet" href="css/colors/bridge.css" />-->
<!--<link rel="stylesheet" href="css/colors/yellow.css" />-->
<!--<link rel="stylesheet" href="css/colors/violet.css" />-->
<!--<link rel="stylesheet" href="css/colors/cyan.css" />-->
<!--<link rel="stylesheet" href="css/colors/mossgreen.css" />-->
</head>

<body>
<div class="site_wrapper">
  <div class="topbar light topbar-padding">
    <div class="container">
      <ul class="toplist toppadding">
         <li class="lineright">E-mail: info@landmarktownships.in</li>
       
  <li class="lineright"><a href="#" data-toggle="modal" data-target="#login-modal">Login</a>
        <div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    	   <div class="modal-dialog">
				<div class="loginmodal-container">
                                    <img src="images/demo/logo.png" alt=""/><br/>
					<br><h1 style="color: blue; font-size: 1.5em;text-transform:none">Login to Your Account</h1><br>
                                        <form action="admin/auth.php" method="post" >
                                            <input style="height:44px" type="email" id="inputEmail" name="username" class="form-control" placeholder="Email address" required autofocus><br/>
                                            <input type="password" id="inputPassword" name="password" class="form-control" placeholder="Password" required>
                                            <br><input type="submit" name="submit" class="login loginmodal-submit" value="submit">
                                        </form>
					
				  <div class="login-help">
					<a style="color:black" href="#">Register</a> - <a style="color:black" href="#">Forgot Password</a>
				  </div>
				</div>
			</div>
		  </div></li>
         
        <li><a href="https://www.facebook.com/Landmark-Townships-418682175184912/" target="_blank"><i class="fa fa-facebook"></i></a></li>
        <li><a href="https://twitter.com/avrsLANDMARK" target="_blank"><i class="fa fa-twitter"></i></a></li>
        <li><a href="https://plus.google.com/115588211747650854969" target="_blank"><i class="fa fa-google-plus"></i></a></li>
        <li class="last"><a href="https://www.linkedin.com/in/landmark-townships-9979b4140/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
      </ul>
    </div>
  </div>
  <div class="clearfix"></div>
  
  <div id="header">
  <div class="container">
        <div class="navbar navbar-default yamm dark">
                <div class="navbar-header">
                  <button type="button" data-toggle="collapse" data-target="#navbar-collapse-grid" class="navbar-toggle"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
                    <a href="index.php" class=""><img src="images/demo/logo.png" alt=""/></a> 
                </div>
                <div id="navbar-collapse-grid" class="navbar-collapse collapse pull-right">
                  <ul class="nav navbar-nav">
                    <li class="dropdown"> <a href="index.php" class="dropdown-toggle ">Home</a>

                    </li>

                    <li class="dropdown"><a href="#" class="dropdown-toggle">About Us</a>
                          <ul class="dropdown-menu" role="menu">
                                <li > <a href="about_us/about_landmark.html">About Landmark Townships</a> </li>
                             
                               <li > <a href="about_us/vision_and_mission.html">Vision and Mission</a> </li>

                            </ul>
                    </li>

                    <li class="dropdown"> <a href="#" class="dropdown-toggle">Projects</a>
                        <ul class="dropdown-menu"> 
                                <li class="dropdown-submenu mul"> <a tabindex="-1" href="#">Ongoing</a>
                                    <ul class="dropdown-menu">
                                            <li class="dropdown-submenu mul"><a href="hill-county.php"> Hill County<i class="fa fa-angle-right pull-right" style=" margin-top:3px" aria-hidden="true"></i></a>
                                            <ul class="dropdown-menu focus">
                                                <li><a href="phase-3.php">Phase-3</a></li>
                                                <li><a href="phase-4.php">Phase-4</a></li>
                                            </ul>
                                            </li>
                                    </ul>
                                </li>

                                <li class="dropdown-submenu mul"><a tabindex="-1"  href="#">Upcoming</a>
                                    <ul class="dropdown-menu">
                                       
                                       <li><a href="resort.php">Hill top Resort</a></li>
                                     </ul>
                                </li>
                                <li class="dropdown-submenu mul"> <a tabindex="-1" href="#">Completed</a>
                                    <ul class="dropdown-menu">
                                            <li class="dropdown-submenu mul"><a href="hill-county.php"> Hill County<i class="fa fa-angle-right pull-right" style=" margin-top:3px" aria-hidden="true"></i></a>
                                            <ul class="dropdown-menu focus">
                                                <li><a href="hill-county.php">Phase-1</a></li>
                                                <li><a href="phase-2.php">Phase-2</a></li>
                                            </ul>
                                            </li>
                                    </ul>
                                </li>
                            </ul> 
                    </li>
                    <li class="dropdown "> <a href="#" class="dropdown-toggle">CSR</a>
                        <ul class="dropdown-menu">
                            <li><a href="csr.php">Gallery</a></li>
                        </ul>
                    </li>
                    <li > <a href="gallery.php" class="dropdown-toggle">Gallery</a> </li>
                    <li class="dropdown "> <a href="#" class="dropdown-toggle active">Career</a>
                        <ul class="dropdown-menu">
                            <li><a href="career.php">Current Opportunities</a></li>
                         </ul>
                    </li>
                     <li  class="dropdown " > <a href="#" class="dropdown-toggle">NRI Corner</a>
                    <ul class="dropdown-menu">
                            <li><a href="why.php">Why Landmark </a></li>
                            <li><a href="faq.php">FAQ</a></li>
                            <li><a href="investment.php">Investment </a></li>
                           
                         </ul>
                          </li>
                    <li > <a href="contact.php" class="dropdown-toggle">Contact</a>

                    </li>
                    <li  class="dropdown " > <a href="#" class="dropdown-toggle">Book Now</a>
                     <ul class="dropdown-menu">
                        <li><a href="phase1_plot_booking.php">Phase-1</a></li>
                        <li><a href="phase2_plot_booking.php">Phase-2</a></li>
                        <li><a href="phase3_plot_booking.php">Phase-3</a></li>
                        <li><a href="phase4_plot_booking.php">Phase-4</a></li>
                        <li><a href="#">Phase-5</a></li>
                        <li><a href="#">Phase-6</a></li>    
                    </ul>
                    </li>
                  </ul>
                </div>
            </div>
        </div>
  </div>


  <!--end section-->
  <div class="clearfix"></div>
<!--end menu-->
  <div class="clearfix"></div>
  
  <section>
    <div class="header-inner two">
     
        <img src="images/about/career.png" style="width: 100%" alt="" class="img-responsive"/> </div>
  </section>
  <!-- end header inner -->
  <div class="clearfix"></div>
  
  <section>
    <div class="pagenation-holder">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <h3 style="color:black">Career : Landmark Townships</h3>
          </div>
          <div class="col-md-6 text-right">
            <div class="pagenation_links"><a href="index.php">Home</a><i> / </i> Career</div>
          </div>
        </div>
      </div>
    </div>
  </section>
 
 <!--end section-->
  <div class="clearfix"></div>
  
  <section class="sec-padding" style="background-image:url('images/bg2.jpg');
border-top: 1px solid #d28415;">
    <div class="container">
      <div class="row">
      <div class="col-md-8 col-sm-12 col-xs-12 bmargin">
      <div class="col-md-12">
          <h4 class="uppercase">Marketing Executive</h4>
          <div class="clearfix"></div>
          <ul class="tabs15">
            <li><a href="#example-15-tab-1" target="_self">Requirements</a></li>
            <li><a href="#example-15-tab-2" target="_self">Desired Skills</a></li>
            <li><a href="#example-15-tab-3" target="_self"> Required</a></li>
            <li><a href="#example-15-tab-4" target="_self">Company Profile </a></li>
            <li><a href="#example-15-tab-5" target="_self">Enquiry </a></li>
          </ul>
          <div class="tabs-content15">
            <div id="example-15-tab-1" class="tabs-panel15">
              <div class="col-md-12">
                <p align="justify">Marketing executives work closely with other employees such as advertising, market research, production, sales and distribution staff. They are responsible for: analysing and investigating price, demand and competition. devising and presenting ideas and strategies.</p>
                <br/>
                <ul class="iconlist">
                  <li><i class="fa fa-long-arrow-right"></i> &nbsp; Implements marketing and advertising campaigns by assembling and analyzing sales forecasts; preparing marketing and advertising strategies, plans, and objectives; planning and organizing promotional presentations; updating calendars.</li>
                  <li><i class="fa fa-long-arrow-right"></i> &nbsp; Tracks product line sales and costs by analyzing and entering sales, expense, and new business data.</li>
                  <li><i class="fa fa-long-arrow-right"></i> &nbsp; Prepares marketing reports by collecting, analyzing, and summarizing sales data.</li>
                  <li><i class="fa fa-long-arrow-right"></i> &nbsp; Keeps promotional materials ready by coordinating requirements with graphics department; inventorying stock; placing orders; verifying receipt.</li>
                  <li><i class="fa fa-long-arrow-right"></i> &nbsp;Supports sales staff by providing sales data, market trends, forecasts, account analyses, new product information; relaying customer services requests.</li>
                </ul>
              </div>
            </div>
            <!-- end tab 1 -->
            
            <div id="example-15-tab-2" class="tabs-panel15">
              <div class="col-md-12">
                <p align="justify">Markets products by developing and implementing marketing and advertising campaigns; tracking sales data; maintaining promotional materials inventory; planning meetings and trade shows; maintaining databases; preparing reports.</p>
                <br/>
                <ul class="iconlist">
                  <li><i class="fa fa-long-arrow-right"></i> &nbsp; Researches competitive products by identifying and evaluating product characteristics, market share, pricing, and advertising; maintaining research databases.</li>
                  <li><i class="fa fa-long-arrow-right"></i> &nbsp; Plans meetings and trade shows by identifying, assembling, and coordinating requirements; establishing contacts; developing schedules and assignments; coordinating mailing lists.</li>
                  <li><i class="fa fa-long-arrow-right"></i> &nbsp; Monitors budgets by comparing and analyzing actual results with plans and forecasts.</li>
                  <li><i class="fa fa-long-arrow-right"></i> &nbsp; Updates job knowledge by participating in educational opportunities; reading trade publications.</li>
                  <li><i class="fa fa-long-arrow-right"></i> &nbsp; Accomplishes organization goals by accepting ownership for accomplishing new and different requests; exploring opportunities to add value to job accomplishments.</li>
                </ul>
              </div>
            </div>
            <!-- end tab 2 -->
            
            <div id="example-15-tab-3" class="tabs-panel15">
              <div class="col-md-12">
               <p align="justify">Essentially, working as a marketing executive is all about strategy, planning, organisation, administration and communication. You’ll most likely be working as part of a dynamic marketing team, so it’s all about getting your heads together, understanding the brief, organising everything and then cracking on and getting it done. Then, and only then, will your marketing campaigns be a success.</p>
                <br/>
                <ul class="iconlist">
                  <li><i class="fa fa-long-arrow-right"></i> &nbsp; Direct Marketing,</li>
                  <li><i class="fa fa-long-arrow-right"></i> &nbsp; Market Segmentation,.</li>
                  <li><i class="fa fa-long-arrow-right"></i> &nbsp; Marketing Research, </li>
                  <li><i class="fa fa-long-arrow-right"></i> &nbsp; Coordination, Project Management, Reporting Research Results,</li>
                  <li><i class="fa fa-long-arrow-right"></i> &nbsp; Understanding the Customer, Process Improvement, Initiative, Planning, Financial Skills</li>
                </ul>
              </div>
            </div>
            <!-- end tab 3 -->
            
            <div id="example-15-tab-4" class="tabs-panel15">
              <div class="col-md-12">
                <h4>We are Looking for young dynamic talents</h4>
                <p align="justify">Landmark Township is one name that's being reinforcing dreams, creating strong foundations and building trust. The Group has been synonymous with excellence in high-end residential developments at most prestigious locations in and around Hyderabad. A young and dynamic company, Landmark Township aims at achieving higher standards in Real estate project management, marketing and customer relationship management. With a strong focus of purpose, the company is dedicated to creating iconic growth and outstanding values..</p>
              </div>
            </div>
            <!-- end tab 4 --> 
            <div id="example-15-tab-5" class="tabs-panel15">
              <div class="col-md-12 smart-forms">
                <h4>Enquiry</h4>
                   <form method="post" action="validation2.php" id="smart-form">
              <div>
                <div class="section">
                  <label class="field prepend-icon">
                    <input type="text" name="sendername" id="sendername" class="gui-input" placeholder="Enter name">
                    <span class="field-icon"><i class="fa fa-user"></i></span> </label>
                </div>
                <!-- end section -->
                
                <div class="section">
                  <label class="field prepend-icon">
                    <input type="email" name="emailaddress" id="emailaddress" class="gui-input" placeholder="Email address">
                    <span class="field-icon"><i class="fa fa-envelope"></i></span> </label>
                </div>
                <!-- end section -->
                
                <div class="section colm colm6">
                  <label class="field prepend-icon">
                    <input type="tel" name="sendertelephone" id="telephone" class="gui-input" placeholder="Telephone">
                    <span class="field-icon"><i class="fa fa-phone-square"></i></span> </label>
                </div>
                <!-- end section -->
                
                <div class="section">
                  <label class="field prepend-icon">
                    <input type="text" name="qualification" id="qualification" class="gui-input" placeholder="Enter Qualification">
                    <span class="field-icon"><i class="fa fa-lightbulb-o"></i></span> </label>
                </div>
                <!-- end section -->
                
                <div class="section">
                  <label class="field prepend-icon">
                    <input type="file" name="resume" id="resume" class="gui-input" placeholder="Resume" required>
                     </label>
                </div>
                <!-- end section --> 
                
                <!--<div class="section">
                            <div class="smart-widget sm-left sml-120">
                                <label class="field">
                                    <input type="text" name="captcha" id="captcha" class="gui-input sfcode" maxlength="6" placeholder="Enter CAPTCHA" >
                                </label>
                                <label class="button captcode">
                                    <img src="php/captcha/captcha.php?<?php echo time();?>" id="captchax" alt="captcha">
                                    <span class="refresh-captcha"><i class="fa fa-refresh"></i></span>
                                </label>
                            </div> 
                        </div>-->
                
                <div class="result"></div>
                <!-- end .result  section --> 
                
              </div>
              <!-- end .form-body section -->
              <div class="form-footer">
                <button type="submit" name="submit" data-btntext-sending="Sending..." class="button btn-primary orange-2">Submit</button>
                <button type="reset" class="button"> Cancel </button>
              </div>
              <center><span class="successs">Message sent successfully.......We Will Contact you Soon</span></center>
              <!-- end .form-footer section -->
            </form>
              </div>
            </div>
          </div>
          <!-- end all tabs --> 
        </div>
        <!--end tabs--> 
        
        <div class="clearfix"></div>
      <br/>
      
      
    

        </div>
        <!--end left column--> 

      
        <div class="col-md-4 col-sm-12 col-xs-12 bmargin">
          <div class="col-md-12 col-sm-12 col-xs-12 nopadding bmargin">
            <h5>Categories</h5>
            <ul class="category-links orange-2">
              <li><a class="active"  href="#">Marketing</a></li>
              <li><a href="#">Business</a></li>
              <li><a href="#">Staff (office)</a></li>
              <li><a href="#">Construction</a></li>
              <li><a href="#">Designer</a></li>
            </ul>
          </div>
          <div class="clearfix"></div>
          <br/>
        
          
          
          
        </div>
        <!--end right column-->

      </div>
    </div>
  </section>
  <!-- end section -->
   <!--end section-->
    <div class="clearfix"></div>
    <section class="sec-bpadding-2"  style="background-image:url('images/bg2.jpg');
border-top: 1px solid #d28415;">
    <div class="container">
      <div class="row">
        <div class="text-box padding-4 section-orange-2">
          <blockquote class="style1"><span>
                  <h3>Our Values</h3>
                  <h5 class="dosis text-white" ><center>Professionalism is paramount.  We will always provide our clients with a professional approach to our services; we will offer our opinions as to what we think in order to help you make a decision.  We will tell you what we think you need to know, not just what you want to hear..</center></h5>
            </span></blockquote>
        </div>
      </div>
    </div>
  </section>
  <!-- end section -->     
          
          
           
  <!--end section-->
  <div class="clearfix"></div>
  
  <a href="#" class="scrollup orange2"></a><!-- end scroll to top of the page--> 
  
</div>
<!--end sitewraper-->
  <!--end section-->
  <div class="clearfix"></div>
  
  <section class="section-dark sec-padding" style="background-image:url('images/bg2.jpg');
border-top: 1px solid #d28415;">
    <div class="container">
      <div class="row">
        <div class="col-md-4 clearfix">
          <div class="item-holder">
            <h4 class="uppercase footer-title less-mar3">About Landmark Townships</h4>
            <div class="footer-title-bottomstrip"></div>
            <div class="clearfix"></div>
          
            <div class="">
            
              <p align="justify">Landmark Townships committed to providing you a higher quality of life and redefining standard of living through innovative real estate products. We distinctively differentiate ourselves through our unvarying focus on 3 core values - Customer Centricity, Quality and Transparency.</p>
           
            </div>
            
          </div>
        </div>
        <!--end item-->
        
        <div class="col-md-3 clearfix">
          <div class="item-holder">
            <h4 class="uppercase footer-title less-mar3">useful links</h4>
            <div class="clearfix"></div>
            <div class="footer-title-bottomstrip"></div>
            <ul class="usefull-links orange2">
              <li><a href="index.php"><i class="fa fa-angle-right"></i> Home</a></li>
              <li><a href="about_us/about_landmark.html"><i class="fa fa-angle-right"></i>About Us</a></li>
              <li><a href="hill-county.php"><i class="fa fa-angle-right"></i> Hill County</a></li>
              <li><a href="gallery.php"><i class="fa fa-angle-right"></i> Gallery</a></li>
             
            </ul>
          </div>
        </div>
        <!--end item-->
        
        <div class="col-md-3 clearfix">
          <div class="item-holder">
            <h4 class="uppercase footer-title less-mar3">Newsletter</h4>
            <div class="clearfix"></div>
            <div class="footer-title-bottomstrip"></div>
            <div class="newsletter">
              <p align="justify">Landmark Townships is one name that's being reinforcing dreams, creating strong foundations and building trust.</p>
              
            </div>
            <div class="margin-top3"></div>
            <ul class="social-icons-3 white">
                <li><a class="twitter" href="https://twitter.com/avrsLANDMARK" target="_blank"><i class="fa fa-twitter"></i></a></li>
                <li><a href="https://www.facebook.com/Landmark-Townships-418682175184912/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                <li><a href="https://plus.google.com/115588211747650854969" target="_blank"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="https://www.linkedin.com/in/landmark-townships-9979b4140/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
            </ul>
            <div class="clearfix"></div>
          </div>
        </div>
        <!--end item-->
        
        <div class="col-md-2 clearfix">
          <div class="item-holder">
            <h4 class="uppercase footer-title less-mar3">useful links</h4>
            <div class="clearfix"></div>
            <div class="footer-title-bottomstrip"></div>
            <ul class="usefull-links orange2">
              <li><a href="csr.php"><i class="fa fa-angle-right"></i> CSR</a></li>
              <li><a href="why.php"><i class="fa fa-angle-right"></i> NRI Corner</a></li>
              <li><a href="career.php"><i class="fa fa-angle-right"></i> Career</a></li>
              <li class="last"><a href="contact.php"><i class="fa fa-angle-right"></i> Contact</a></li>
            </ul>
          </div>
        </div>
        <!--end item--> 
        
      </div>
    </div>
  </section>
  <!--end section-->
  <div class="clearfix"></div>
  
  <section class="section-copyrights sec-moreless-padding" style="background-image:url('images/bg2.jpg');
border-top: 1px solid #d28415;">
    <div class="container">
      <div class="row">
         <div class="col-md-12"> <span>Copyright © 2017. Landmark Townships, Hyderabad. l Design & Developed By &nbsp;&nbsp;<a href="http://www.digantara.com" target="_blank" style="color:yellow;">Digantara Consulting</a> | All rights reserved.</span></div>
      </div>
    </div>
  </section>
 <!--end section-->
  <div class="clearfix"></div>
  
  <a href="#" class="scrollup orange2"></a><!-- end scroll to top of the page--> 

<!-- ========== demo panel ========== -->

<div id="demo-selector" class="text-center"> <a href="javascript:void(0);" class="demo-close"><span><i class="fa fa-phone"></i></span> <br/>
  Enquiry</a>
    <div class="smart-forms bmargin">
  <h5 class="title-big">Send Your Enquiry<br/>
    <span>Contact us</span></h5>
    
    <form method="post" action="enquiry.php" id="smart-form">
              <div>
                <div class="section">
                  <label class="field prepend-icon" style="width:90%">
                    <input type="text" name="name" id="sendername" class="gui-input" placeholder="Enter name">
                    <span class="field-icon"><i class="fa fa-user"></i></span> </label>
                    
                </div>
                <!-- end section -->
                
                <div class="section">
                  <label class="field prepend-icon" style="width:90%">
                    <input type="email" name="email" id="emailaddress" class="gui-input" placeholder="Email address">
                    <span class="field-icon"><i class="fa fa-envelope"></i></span> </label>
                    
                </div>
                <!-- end section -->
                
                <div class="section colm colm6">
                  <label class="field prepend-icon" style="width:90%">
                    <input type="tel" name="mobile" id="telephone" class="gui-input" placeholder="Mobile">
                    <span class="field-icon"><i class="fa fa-phone-square"></i></span> </label>
                  
                </div>
                <!-- end section -->
                
             
                <!-- end section -->
                
                <div class="section">
                  <label class="field prepend-icon" style="width:90%">
                    <textarea class="gui-textarea" id="sendermessage" name="message" placeholder="Enter message"></textarea>
                    <span class="field-icon"><i class="fa fa-comments"></i></span></label>
                </div>
                <!-- end section --> 
                
             
                
                <div class="result"></div>
                <!-- end .result  section --> 
                
              </div>
              <!-- end .form-body section -->
              <div class="form-footer">
                <button type="submit" name="submit" data-btntext-sending="Sending..." class="button btn-primary orange-2">Submit</button>
                
              </div>
              
              <!-- end .form-footer section -->
            </form>
    </div>
  
</div>
<!-- ========== end demo panel ========== --> 

<!-- ========== Style swicher ========== -->

<!--<div id="style-selector" class="text-center"> <a href="javascript:void(0);" class="btn-close"><i class="fa fa-wrench"></i></a>
  <h5 class="title-big">Enquiry Form</h5>
  <div class="style-selector-wrapper">
    <h5 class="title">Choose Layout</h5>
    <div class="clearfix"></div>
    <a class="btn-gray active" href="index.html">Wide</a> 
    <div class="clearfix"></div>
    <br/>
    <h5 class="title align-left">PREDEFINED SKINS</h5>
    <ul class="pre-colors-list">
      <li><a title="default" href="css/colors/default.css"><span class="pre-color-skin-1"></span></a></li>
      <li><a title="light blue" href="css/colors/lightblue.css"><span class="pre-color-skin-2"></span></a></li>
      <li><a title="orange" href="css/colors/orange.css"><span class="pre-color-skin-4"></span></a></li>
      <li><a title="green" href="css/colors/green.css"><span class="pre-color-skin-3"></span></a></li>
      <li><a title="pink" href="css/colors/pink.css"><span class="pre-color-skin-5"></span></a></li>
      <li class="last"><a title="red" href="css/colors/red.css"><span class="pre-color-skin-6"></span></a></li>
      <li><a title="purple" href="css/colors/purple.css"><span class="pre-color-skin-7"></span></a></li>
      <li><a title="bridge" href="css/colors/bridge.css"><span class="pre-color-skin-8"></span></a></li>
      <li><a title="yellow" href="css/colors/yellow.css"><span class="pre-color-skin-9"></span></a></li>
      <li><a title="violet" href="css/colors/violet.css"><span class="pre-color-skin-10"></span></a></li>
      <li><a title="cyan" href="css/colors/cyan.css"><span class="pre-color-skin-11"></span></a></li>
      <li class="last"><a title="moss green" href="css/colors/mossgreen.css"><span class="pre-color-skin-12"></span></a></li>
    </ul>
    <h5 class="title align-left">bg pattrens</h5>
    <ul class="bg-pattrens-list">
      <li><a href="#"><span class="bg-pattren-1"></span></a></li>
      <li><a href="#"><span class="bg-pattren-2"></span></a></li>
      <li><a href="#"><span class="bg-pattren-3"></span></a></li>
      <li><a href="#"><span class="bg-pattren-4"></span></a></li>
      <li><a href="#"><span class="bg-pattren-5"></span></a></li>
      <li class="last"><a href="#"><span class="bg-pattren-6"></span></a></li>
      <li><a href="#"><span class="bg-pattren-7"></span></a></li>
      <li><a href="#"><span class="bg-pattren-8"></span></a></li>
      <li><a href="#"><span class="bg-pattren-9"></span></a></li>
      <li><a href="#"><span class="bg-pattren-10"></span></a></li>
      <li><a href="#"><span class="bg-pattren-11"></span></a></li>
      <li class="last"><a href="#"><span class="bg-pattren-12"></span></a></li>
    </ul>
  </div>
</div>-->
<!-- ========== end style swicher ========== --> 

<!-- =============== JS FILES =============== --> 

<!-- ========== Js Files ========== -->
 

<script type="text/javascript" src="js/universal/jquery.js"></script> 
<script src="js/bootstrap/bootstrap.min.js" type="text/javascript"></script> 
<script src="js/tabs/assets/js/responsive-tabs.min.js" type="text/javascript"></script>
<script src="js/mainmenu/customeUI.js"></script> 
<script src="js/mainmenu/jquery.sticky.js"></script> 
<script src="js/scrolltotop/totop.js"></script> 
<script type="text/javascript" src="js/smart-forms/jquery.form.min.js"></script> 
<script type="text/javascript" src="js/smart-forms/jquery.validate.min.js"></script> 
<script type="text/javascript" src="js/smart-forms/additional-methods.min.js"></script> 
<script type="text/javascript" src="js/smart-forms/smart-form.js"></script> 
<script src="js/owl-carousel/owl.carousel.js"></script> 
<script src="js/owl-carousel/custom.js"></script> 
<script type="text/javascript" src="js/tabs/custom.js"></script> 
<script type="text/javascript" src="js/tabs/smk-accordion.js"></script>
<script src="js/custom-scrollbar/jquery.mCustomScrollbar.concat.min.js"></script> 
<script src="js/style-swicher/style-swicher.js"></script> 
<script src="js/style-swicher/custom.js"></script> 
<script src="js/scripts/functions.js" type="text/javascript"></script>

</body>


</html>
