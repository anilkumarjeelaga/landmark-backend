<?php 
$hostname = "localhost";
$username = "root";
$password = "";
$database = "landmark";

mysql_connect($hostname,$username,$password) or die ("connection failed");
mysql_select_db($database) or die ("error connect database");

IF(ISSET($_POST['submit'])){
$email = $_POST['email'];
$password = md5($_POST['password']);
$cek = mysql_num_rows(mysql_query("SELECT * FROM admin_login WHERE email='$email' AND password='$password'"));
$data = mysql_fetch_array(mysql_query("SELECT * FROM admin_login WHERE email='$email' AND password='$password'"));
IF($cek > 0)
{
 session_start();
 $_SESSION['email'] = $data['email'];
 $_SESSION['name'] = $data['name'];
 echo "<script language=\"javascript\">alert(\"Welcome to Landmark Townships\");document.location.href='admin/index.php';</script>";
}else{
 echo "<script language=\"javascript\">alert(\"Invalid username or password\");document.location.href='login.php';</script>";
}
}
?>
