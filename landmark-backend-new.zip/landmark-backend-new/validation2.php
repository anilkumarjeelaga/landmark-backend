<?php

require('phpmailer/class.phpmailer.php');

// Initialize variables to null.
$name ="";		//Sender Name
$lname ="";		//Sender Name
$email =""; 	//Sender's email ID
$phone ="";	//Subject of mail
$gender ="";	//Sender's Message 
$dob="";
$dob2="";
$dob3="";
$qualification="";
$degree="";
$errorss="";
$nameError ="";			
$emailError ="";
$phoneError ="";
$degreeError ="";
$dobError="";
$genderError="";
$successMessage ="";

//On submitting form below function will execute

if(isset($_POST['submit']))
  {
    
        
   
    
  // checking null values in name
    if (empty($_POST["name"])){
        $nameError = "Name is required";
      } 
   else {
       $name = ($_POST["name"]);
       // check name only contains letters and whitespace
      
     }
   
      
 // checking null values in email 
   if (empty($_POST["emailaddress"])) {
       $emailError = "Email is required";
      } 
   else {
      $email = ($_POST["emailaddress"]);
      }
 // checking null values in phone    
   if (empty($_POST["sendertelephone"])) {
      $phoneError = "phone is required";
     }
     else { 
    
	   $phone = ($_POST["sendertelephone"]); 
        if (!preg_match("/^[789]\d{9}$/",$phone )){
            $phoneError = "Invalid Phone"; 
         }

	 }
       
       		//Sender Name
	//Subject of mail
	//Sender's Message 

$qualification=($_POST["qualification"]);


 // checking null values in subject    
   
  // checking null values in all fields  
if( !($name=='') && !($email=='') && !($phone=='') )

  {// checking valid email
    if (preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$email) ) {
      
		$header= $name."<". $email .">";
                $headers = "noreply@landmarktownshios.in";
                 
     /* Let's prepare the message for the e-mail */
		$msg = "Hello! $name

 Thank you...! For Contacting Us.

 Name: $name  
 E-mail: $email
 Phone: $phone    

 Qualification: $qualification 
  ";

$body = " $name Contacted Us.

 Here are some information about $name.
 Name: $name 
 E-mail: $email
 Phone: $phone   
 Qualification: $qualification
   
";
$mail = new PHPMailer;
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPSecure = 'tls';
$mail->SMTPAuth = true;
$mail->Username = "digantara.consulting@gmail.com";
$mail->Password = "Digantara@1982";
$mail->addAddress("digantara.consulting@gmail.com");

$mail->msgHTML($body);
$mail->AddAttachment($_FILES['resume']['tmp_name']); 
$mail->IsHTML(true);  
if($mail->Send()) {
    $successMessage ="Mail Sent successfully";
	
} else {
	$successMessage ="Problem in Sending Mail";
}	
       }
/* Send the message using mail() function */
  
  
else { $emailError = "Invalid Email";  }

 }
 


	
  }
?>